# My Favorite Places

Mike Johnson's assignment for Spring Quarter 2019 (TA Marcela) - example files
